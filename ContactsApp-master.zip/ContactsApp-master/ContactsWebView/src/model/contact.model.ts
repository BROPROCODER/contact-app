export class Contact {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    birthDay: Date;
}
